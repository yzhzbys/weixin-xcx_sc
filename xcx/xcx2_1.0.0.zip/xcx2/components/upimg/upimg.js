// components/upimg/upimg.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    src:{
      type:"String",
      value:""
    }

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
      //点击删除图片
    handledelimg(e){
      const {index} = e.currentTarget.dataset;
      //触发父组件的事件
      this.triggerEvent("upimgdel",{index})
    },
  }
})
