// components/tabs/tabs.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    //此处定义了一个组件属性'tabs'，这是一个数组
    tabs:{
      type:Array,
      value:[]
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    //定义点击事件
    handletap(yuyu){
      //获取点击数据的索引
      const {index}=yuyu.currentTarget.dataset;
      console.log(index)
      //触发父组件的事件
      this.triggerEvent("tabschange",{index})
    }

  },
  //样式
  externalClasses:['tabs-style']
})
