// pages/goos_detail/index.js
import{request} from "../../request/index.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods_xq:{},
    iscollect:false

  },
  //定义一个全局变量存放预览图片,状态
  goodsinfo:{},
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  //获取商品详情数据
  async getgoods_detail(goods_id){
    const goods_xq=await request({url:"/goods/detail",data:{goods_id}})
    this.goodsinfo=goods_xq;
    //判断商品是否被收藏
    let collect=wx.getStorageSync('collect')||[];
    let iscollect = collect.some(v=>v.goods_id===this.goodsinfo.goods_id)
    this.setData({
      
      goods_xq:{
        goods_name:goods_xq.goods_name,
        pics:goods_xq.pics,
        goods_price:goods_xq.goods_price,
         //由于部分系统不支持webp图片格式 可暂时进行格式替换，前提是有对应更改后格式的文件
        goods_introduce:goods_xq.goods_introduce.replace(/\.webp/g,'.png')

      },
      iscollect
    })
  },
  //轮播图的点击预览事件
  handlepreviewimage(yuyu){
    const urls= this.goodsinfo.pics.map(v=>v.pics_big);
    const{index}=yuyu.currentTarget.dataset;
    
    wx.previewImage({
      current:urls[index],
      urls: urls,
    });
  },
  // 点击加入购物车
  // 1 绑定点击事件
  // 2 获取缓存中的购物车数据 数组格式
  // 3 先判断 当前商品是否已经存在于购物车中
  // 4 存在则修改商品数据 执行购物车
  // 5 不存在 直接给购物车添加
  // 6 弹出提示
  handlecartadd(){
    
    //获取缓存中的购物车 数组
    let cart=wx.getStorageSync('cart')||[];
    //判断 商品对象是否存在于购物车数组中
    let index=cart.findIndex(v=>v.goods_id===this.goodsinfo.goods_id)
    if(index===-1){
      //不存在 第一次加此处添加属性num，checked
      this.goodsinfo.num=1;
      this.goodsinfo.checked=true;
      cart.push(this.goodsinfo);
    }else{
      //已存在 执行加一
      cart[index].num++;
    }
    //把购物车重新添加回缓存中
    wx.setStorageSync("cart",cart);
    //弹窗
    wx.showToast({
      title: '加入成功',
      icon:'success',
      mask:true,
      duration:250
    })

  
  },
  //点击收藏
  handlecollect(){
    let iscollect=false;
    //从缓存中获取收藏数组
    let collect=wx.getStorageSync('collect')||[];
    //判断收藏状态 findindex(查询满足条件的值在数组中的索引位置，没有时返回-1)
    let index=collect.findIndex(v=>v.goods_id===this.goodsinfo.goods_id);
    if(index!==-1){
      //splice修改原数组 删除
      collect.splice(index,1);
      iscollect=false;
      wx.showToast({
        title: '取消收藏',
      })
    }else{
      //push在数组末尾添加新元素
      collect.push(this.goodsinfo);
      iscollect=true;
      wx.showToast({
        title: '收藏成功',
      })
    }
    wx.setStorageSync('collect', collect);
    this.setData({iscollect});
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //加载缓存中的商品收藏数据
    let pages = getCurrentPages();
    let currentpage=pages[pages.length-1];
    let options=currentpage.options;
    const {goods_id}=options;
    this.getgoods_detail(goods_id);
    

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})