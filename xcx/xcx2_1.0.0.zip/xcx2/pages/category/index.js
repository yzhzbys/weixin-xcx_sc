// const { request } = require("../../request/index.js")
// require方法只适用于服务器端不被大多数浏览器支持故使用import
import{request}from "../../request/index.js";
// pages/category/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    leftlist:[],
    rightlist:[],
    //leftmenu的状态值
    currentindex:0,
    scroll_top:0
  },
  cates:[],

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //获取本地存储数据
    const cates = wx.getStorageSync("cates_key");
    if(!cates){
      this.getrequest();
    }else{
      //如果刷新时间低于10s则使用旧数据
      if(Date.now()-cates.time>1000*10){
        this.getrequest();
      }else{
        this.cates=cates.data;
        //构造出leftlist数据
        let leftlist=this.cates.map(s=>s.cat_name);
        let rightlist=this.cates[0].children;
        this.setData({
          leftlist,
          rightlist
        })
        console.log('使用了缓存数据')
      }
    }
    
    console.log('页面加载完成')
  },
  //使用es7的async await来异步
  async getrequest(){
    // request({url:"/categories"})
    // .then(res=>{

    //   this.cates=res.data.message;

    //   //存储接口数据到本地
    //   wx.setStorageSync('cates_key', {time:Date.now(),data:this.cates})
      
    //   //构造出leftlist数据
    //   let leftlist=this.cates.map(s=>s.cat_name);
    //   let rightlist=this.cates[0].children;
    //   this.setData({
    //     leftlist,
    //     rightlist
    //   }
        
    //   )
    // })
    const res =await request({url:"/categories"});
    this.cates=res;
    //存储接口数据到本地
    wx.setStorageSync('cates_key', {time:Date.now(),data:this.cates})
    
    //构造出leftlist数据
    let leftlist=this.cates.map(s=>s.cat_name);
    let rightlist=this.cates[0].children;
    this.setData({
      leftlist,
      rightlist
    })

  },
  //点击事件(实际上此时才发生其他数据的缓存)
  handlelefttap(e){
    const{index}=e.currentTarget.dataset;
    this.setData({
      currentindex:index
    })
    //构造新的rightlist
    let rightlist=this.cates[index].children;
    this.setData({
      rightlist,
      //点击后将rightlist返回最顶部
      scroll_top:0
    }
    )
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})