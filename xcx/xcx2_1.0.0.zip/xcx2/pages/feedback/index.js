// pages/feedback/index.js

/* 
1 点击 “+” 触发tap点击事件
  1 调用小程序内置的 选择图片的 api
  2 获取到 图片的路径  数组
  3 把图片路径 存到 data的变量中
  4 页面就可以根据 图片数组 进行循环显示 自定义组件
2 点击 自定义图片 组件
  1 获取被点击的元素的索引
  2 获取 data中的图片数组
  3 根据索引 数组中删除对应的元素
  4 把数组重新设置回data中
3 点击 “提交”
  1 获取文本域的内容 类似 输入框的获取
    1 data中定义变量 表示 输入框内容
    2 文本域 绑定 输入事件 事件触发的时候 把输入框的值 存入到变量中 
  2 对这些内容 合法性验证
  3 验证通过 用户选择的图片 上传到专门的图片的服务器 返回图片外网的链接
    1 遍历图片数组 
    2 挨个上传
    3 自己再维护图片数组 存放 图片上传后的外网的链接
  4 文本域 和 外网的图片的路径 一起提交到服务器 前端的模拟 不会发送请求到后台。。。 
  5 清空当前页面
  6 返回上一页 
 */

Page({

  /**
   * 页面的初始数据
   */
  data: {
    tablist:[
      {
        id:0,
        value:"体验问题",
        isActive:true
      },
      {
        id:1,
        value:"商品、商家投诉",
        isActive:false
      }],
      chooseimg:[],
      textarea:""
  },
  //图片路径
  uploadimg:[],
   //切换tab--自定义组件tabs的回调事件
   tablistchange(yuyu){
    //获取被点击的tabs索引
    const {index}=yuyu.detail;
    //修改源数组
    let{tablist}=this.data;
    //foreach中的语法foreach(function(e,i,a)) 
    //e是必需/当前元素currentValue,i是可选/当前元素的索引值index,a是可选/当前元素所属的数组对象
    tablist.forEach((e,i)=>i===index?e.isActive=true:e.isActive=false)
    //赋值tabs回data
    this.setData({
      tablist
    })
  },
  //添加图片wx.chooseImage
  handlechoose(){
    wx.chooseImage({
      count: 9,
      sizeType :	['original', 'compressed'] ,
      sourceType : 	['album', 'camera'],
      success:(res)=>{
        console.log(res);
        this.setData({
          
          //需要将依次上传的图片数组拼接 chooseimg: 
          chooseimg:[...this.data.chooseimg,...res.tempFilePaths]
        })
        
      }
    })

  },
  //点击删除图片--自定义组件upimg的回调事件
  handledelimg(e){
    const {index} = e.detail;
    let {chooseimg}=this.data;
    chooseimg.splice(index,1);
    this.setData({chooseimg});
  },
  //获取input内容
  handleinput(e){
    this.setData({
      textarea:e.detail.value
    });
  },
  //点击提交按钮
  handleupload(e){
    const {textarea,chooseimg}=this.data;
    if(!textarea.trim()){
      wx.showToast({
        title: '输入不正确',
        icon:'none'
      })
      return;
    }
    wx.showLoading({
      title: '上传中',
      
     
    });
    //判断有无图片
    if(chooseimg.length!=0){
      // 验证通过 用户选择的图片 上传到专门的图片的服务器 返回图片外网的链接
      chooseimg.forEach((v,i)=>{
        wx.uploadFile({
          // 图片要上传到哪里
          url: 'https://img.coolcr.cn/api/upload',
          // 被上传的文件的路径
          filePath: v,
          // 上传的文件的名称 后台来获取文件  file
          name: "image",
          // 顺带的文本信息
          formData: {},
          success: (result) => {
            console.log(result);
            let url=JSON.parse(result.data).data.url;
            this.uploadimg.push(url);
            console.log(this.uploadimg);
            //内容判断并上传后显示上传结束
            if(i===chooseimg.length-1){
              wx.hideLoading({
                success: (res) => {
                  console.log('上传完成，此处将返回url和text到接口提交');
                  this.setData({
                    chooseimg:[],
                    textarea:""
                  });
                  wx.showToast({
                    title: '上传成功',
                  });
                  //自动返回上一级
                  wx.navigateBack({
                    delta: 0,
                  })  
                },
                fail :(err) => {
                  console.log(err);}
              });
              
            }
           
          }
        })
      }
      )
    }else{
      wx.hideLoading({
        success: (res) => {
          console.log(res);
          console.log('上传完成，此处将返回url和text到接口提交--text');
          this.setData({
            chooseimg:[],
            textarea:""
          });
          wx.showToast({
            title: '上传成功',
          });
          //自动返回上一级
          wx.navigateBack({
            delta: 0,
          })  
        },
      });
      
    }
    
   
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})