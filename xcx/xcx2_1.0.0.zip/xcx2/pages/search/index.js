// pages/search/index.js
import{request} from "../../request/index"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods:[],
    isfocus:false,
    invalue:""
  
  },
  //定时器
  timeid:-1,
  //搜索input，输入事件
  handlesearch(e){
    console.log(e)
    //获取文本框内容
    const vchar=e.detail.value;
    console.log(vchar);
    //判断输入栏内容是否为空 trim去空格
    if(!vchar.trim()){
      this.setData({
        goods:[],
        isfocus:false
      });
      clearTimeout(this.timeid);
      return;
    }
    
    this.setData({isfocus:true});
    //设置一个定时器防抖，发送搜索请求
    clearTimeout(this.timeid);
    this.timeid=setTimeout(
      ()=>{this.searchurl(vchar);},500
    );
    

  },
  //搜索请求，此处传入值必须定义为query
  async searchurl(query){
    const answer= await request({'url':'/goods/qsearch',data:{query}});
    console.log(answer);
    this.setData({goods:answer});
  },
  //取消按钮，删除所有内容
  handledel(){
    this.setData({
      isfocus:false,
      goods:[],
      invalue:''
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})