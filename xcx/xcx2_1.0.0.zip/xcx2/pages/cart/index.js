// pages/cart/index.js
import {chooseAddress,showModal1,showToast}from "../../utils/asyncWx.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address:{},
    cart:[],
    allchecked:false,
    allprice:0,
    allnum:0


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  //按钮转化事件
  async handle(){
    try{
      const res1= await wx.getSetting();
      let address =await wx.chooseAddress();
      address.all=address.provinceName+address.cityName+address.countyName+address.detailInfo;
      wx.setStorageSync('address', address);
    }catch(err){
      console.log(err);
    }
  },
  //点击选取框事件
  handlecheck(e){
    //获取对应的id，用此id索引,然后改变checked，然后再计算数量和金额,把数据返回到缓存和data中
    const id=e.currentTarget.dataset.id;
    let {cart}=this.data;
    let index=cart.findIndex(v=>v.goods_id===id);
    cart[index].checked=!cart[index].checked;
    this.setfoot(cart);
    wx.setStorageSync('cart',cart);
  },
  //点击全选按钮事件
  handleqx(e){
    //获取data中的变量，取反，遍历列表的checked并改变，计算商品数量价格，设置回缓存
    let{cart,allchecked}=this.data;
    allchecked=!allchecked;
    cart.forEach(v=>v.checked=allchecked);
    this.setfoot(cart);
    wx.setStorageSync('cart',cart);
  },
  //-+按钮
  async handlenum(e){
    const {id,operation}=e.currentTarget.dataset;
    let{cart}=this.data;
    //findIndex返回第一次符合条件的索引位置
    const index=cart.findIndex(v=>v.goods_id===id);
    //判断是否删除
    if(cart[index].num===1&&operation===-1){
    
      // wx.showModal({
      //   content: '要从列表中删除商品吗',
      //   title: '提示',
      //   success: (res) => {
      //     if (res.confirm) {
      //       cart.splice(index,1);this.setfoot(cart);wx.setStorageSync('cart',cart);
      //     } else if (res.cancel) {
      //       console.log('用户点击取消')
      //     }
      //   }
      // })
      const res=await showModal1({content:'要从列表中删除商品吗'});
      if (res.confirm) {
              cart.splice(index,1);this.setfoot(cart);wx.setStorageSync('cart',cart);
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
    }else{
      cart[index].num+=operation;
      this.setfoot(cart);
      wx.setStorageSync('cart',cart)};
    

  },
  //结算按钮
  async handlepay(){
    const {address,allnum}=this.data;
    if(!address.userName){
      await showToast({title:'收货地址不能为空'});
      return;
    }
    if(allnum===0){
      await showToast({title:'购物篮不能为空'});
      return;
    }
    wx.navigateTo({
      url: '/pages/pay/index',
    })
  },
  //此处计算商品总价，数量,全选按钮显示
  setfoot(cart){
    //设置allchecked为true，假如所有商品都被选中则为true，若有一个未选中就变成false
    let allchecked=true;
    let allprice=0;
    let allnum=0;
    cart.forEach(v=>{
      if(v.checked){
        allprice+=v.goods_price*v.num;
        allnum+=v.num;
      }else{
        allchecked=false;
      }
    })
    //假如cart数组为空，foreach不会执行，，所以需要添加一个例外
    allchecked=cart.length!=0?allchecked:false;
    this.setData({
      cart,allchecked,allprice,allnum
    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //获取缓存中的信息
    const address=wx.getStorageSync('address');
    const cart=wx.getStorageSync('cart')||[];
    //若cart数组为空，every返回值则是true,所以设置若cart为空，返回false
    // const allchecked=cart.length?cart.every(v=>v.checked):false;
    this.setfoot(cart);
    
    this.setData({
      address
    })


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})