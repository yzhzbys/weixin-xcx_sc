// pages/order/index.js
import{request}from "../../request/index.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tablist2:[
      {
        id:0,
        value:"全部",
        isActive:true
      },
      {
        id:1,
        value:"待付款",
        isActive:false
      },
      {
        id:3,
        value:"待发货",
        isActive:false
      },
      {
        id:4,
        value:"退款/退货",
        isActive:false
      }
    ],
    orders:[]

  },
  //自定义组件tabs的回调事件
  tablist2change(yuyu){
    //获取被点击的tabs索引
    const {index}=yuyu.detail;
    this.changeindex(index);
    
  },
  //在tab中根据索引选中标题
  changeindex(index){
    //修改源数组
    let{tablist2}=this.data;
    //foreach中的语法foreach(function(e,i,a)) 
    //e是必需/当前元素currentValue,i是可选/当前元素的索引值index,a是可选/当前元素所属的数组对象
    tablist2.forEach((e,i)=>i===index?e.isActive=true:e.isActive=false)
    //赋值tabs回data
    this.setData({
      tablist2
    })
    //再次调用getorder定位
    this.getorders(index+1);
  },
  //定义获取订单列表的方法(orders:[])
  async getorders(type){
    const res=await request({url:'/my/orders/all',data:{type}})
    console.log(res);
    this.setData({
      //此处map添加一个将秒转码后的日期
      orders:res.orders.map(v=>({...v,time:(new Date(v.create_time*1000).toLocaleString())}))
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //判断是否有token值（authorization）
    const token=wx.getStorageSync('token')
    if(!token){
      wx.navigateTo({
        url: '/pages/auth/index',
      });
      return;
    }
    //onshow无法接收options参数
    //获取当前页面栈数组，最大为10
    let pages=getCurrentPages();
    console.log(pages);
    //获取当前页面的options（页面参数）
    let currt=pages[pages.length-1];
    console.log(currt.options);
    //获取订单历史 获取url上的type参数
    const {type}=currt.options;
    // 激活选中页面标题 当 type=1 index=0 
    this.changeindex(type-1);
    this.getorders(type);

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})