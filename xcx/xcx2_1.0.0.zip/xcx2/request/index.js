//设置一个计时器
let yuyutime=0;
export const request=(params)=>{
  
  //判断释放需要token，自动添加header/...声明可变长参数
  let header={...params.header};
  if(params.url.includes('/my/')){
    header['Authorization']=wx.getStorageSync('token');
  }
  
  yuyutime++;

  //显示加载动画效果
  wx.showLoading({
    title: '加载中',
    //mask:true透明蒙版防止误触
    mask:true
  });
  //定义一个公共的接口url:"https://api-hmugo-web.itheima.net/api/public/v1/"
  const baseurl="https://api-hmugo-web.itheima.net/api/public/v1";
  return new Promise((resolve,reject)=>{
    wx.request({
      ...params,
      //此处的第二个header为带authorization值的参数，如果不在此处传入authorization则无法传入
      header:header,
      url:baseurl+params.url,
      success:(res)=>{
        resolve(res.data.message);
      },
      fail:(err)=>{
        reject(err);
      },
      complete:()=>{
        yuyutime--;
        if(yuyutime===0){
          wx-wx.hideLoading({
            success: (res) => {},
            fail: (res) => {},
            complete: (res) => {},
          })
        }
      }
    })
  })
}