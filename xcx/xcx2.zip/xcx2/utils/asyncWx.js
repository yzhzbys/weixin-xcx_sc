export const chooseAddress=()=>{
  return new Promise((resolve,reject)=>{
    wx.chooseAddress({
      success: (result) => {
        resolve(result);
      },
      fail:(err)=>{
        reject(err);
      }
    });
  })
};
//promise形式的showmodal1提示框
export const showModal1=({content})=>{
  return new Promise((resolve,reject)=>{
      wx.showModal({
        content: content,
        title: '提示',
        success: (res) => {
         resolve(res);
        }
      })
  })
};
export const showToast=({title})=>{
return new Promise((resolve,reject)=>{
    wx.showToast({
      icon: 'none',
        title: title,
      success: (result) => {
        
        resolve(result);
      },
      fail:(err)=>{
        reject(err);
      }
    });
  })
};
//wx-login
export const login=()=>{
  return new Promise((resolve,reject)=>{
      wx.login({
        timeout:10000,
        success: (result) => {
          
          resolve(result);
        },
        fail:(err)=>{
          reject(err);
        }
      });
    })
  };
  //wx-requestPayment微信支付
export const requestPayment=(pay)=>{
  return new Promise((resolve,reject)=>{
     wx.requestPayment({
      //  nonceStr: 'nonceStr',
      //  package: 'package',
      //  paySign: 'paySign',
      //  timeStamp: 'timeStamp',
      ...pay,
      success: (result) => {
          
        resolve(result);
      },
      fail:(err)=>{
        reject(err);
      }
     })
    })
  };