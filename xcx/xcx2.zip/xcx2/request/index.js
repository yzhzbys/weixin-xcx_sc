//设置一个计时器
let yuyutime=0;
export const request=(params)=>{
  yuyutime++;
  //显示加载动画效果
  wx.showLoading({
    title: '加载中',
    //mask:true透明蒙版防止误触
    mask:true
  });
  //定义一个公共的接口url:"https://api-hmugo-web.itheima.net/api/public/v1/"
  const baseurl="https://api-hmugo-web.itheima.net/api/public/v1";
  return new Promise((resolve,reject)=>{
    wx.request({
      ...params,
      url:baseurl+params.url,
      success:(res)=>{
        resolve(res.data.message);
      },
      fail:(err)=>{
        reject(err);
      },
      complete:()=>{
        yuyutime--;
        if(yuyutime===0){
          wx-wx.hideLoading({
            success: (res) => {},
            fail: (res) => {},
            complete: (res) => {},
          })
        }
      }
    })
  })
}