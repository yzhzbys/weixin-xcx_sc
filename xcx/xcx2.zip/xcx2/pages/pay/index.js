// pages/pay/index.js
import {chooseAddress,showModal1,showToast,requestPayment}from "../../utils/asyncWx.js"
import{request}from '../../request/index.js'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address:{},
    cart:[],
    allprice:0,
    allnum:0


  },
  async handlezhifu(){
    try{
      
    const token=wx.getStorageSync('token');
    if(!token){
      wx-wx.navigateTo({
        url: '/pages/auth/index',
      });
      return;
    }
    console.log('有token');
    //创建订单
    //准备请求头参数
    const header={Authorization:token};
    //准备请求体参数
    const order_price=this.data.allprice;
    const consignee_addr=this.data.address.all;

    const cart=this.data.cart;
    let goods=[];
    // push() 方法可向数组的末尾添加一个或多个元素，并返回新的长度
    cart.forEach(v=>goods.push({
      goods_id:v.goods_id,
      goods_number:v.num,
      goods_price:v.goods_price
    }));
    const orderparams={order_price,consignee_addr,goods};
    //发送请求
    const {order_number} = await request({url:'/my/orders/create',method:'post',data:orderparams,header:header});
    // console.log(res);
    // const number=res.order_number;
    console.log(order_number);
    //发起预支付接口
    const {pay} = await request({url:'/my/orders/req_unifiedorder',method:'post',data:{order_number},header:header});
    console.log(pay);
    //发起支付
    const res =await requestPayment(pay);
    console.log(res);
    //查询订单状态
    const res2 = await request({url:'/my/orders/chkOrder',method:'post',data:{order_number},header:header});
    console.log(res2);
    await showToast({title:'支付成功'});
    //支付完成后手动删除已支付商品，因为在onshow中过滤了card
    // let newcart =wx.getStorageSync('cart');
    // newcart=newcart.filter(v=>!v.checked);
    // wx-wx.setStorageSync('cart', newcart);

  
    }catch(err){
      await showToast({title:'支付失败'});
      console.log(err);
      //同下，
      let newcart =wx.getStorageSync('cart');
      newcart=newcart.filter(v=>!v.checked);
      wx-wx.setStorageSync('cart', newcart);
      //因为无法支付成功，所以暂时把跳转页面改下来
      wx.navigateTo({
        url:'/pages/order/index'
      });
    }
    
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //获取缓存中的信息
    const address=wx.getStorageSync('address');
    let cart=wx.getStorageSync('cart')||[];
    //若cart数组为空，every返回值则是true,所以设置若cart为空，返回false
    // const allchecked=cart.length?cart.every(v=>v.checked):false;
    // 此处过滤cart/checked为true
    cart=cart.filter(v=>v.checked);

    let allprice=0;
    let allnum=0;
    cart.forEach(v=>{
        allprice+=v.goods_price*v.num;
        allnum+=v.num;
    })
    this.setData({
      cart,address,allprice,allnum
    });



  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})