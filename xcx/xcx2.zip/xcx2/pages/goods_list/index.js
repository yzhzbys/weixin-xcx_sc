// pages/goods_list/index.js
import{request}from "../../request/index.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tablist:[
      {
        id:0,
        value:"综合",
        isActive:true
      },
      {
        id:1,
        value:"价格",
        isActive:false
      },
      {
        id:3,
        value:"销量",
        isActive:false
      }
    ],
    goods_list:[],

  },
  queryparams:{
    query:"",
    cid:"",
    pagenum:1,
    pagesize:10
  },
  //定义全局变量总页码数
  totalpages:1,
  //自定义组件tabs的回调事件
  tablistchange(yuyu){
    //获取被点击的tabs索引
    const {index}=yuyu.detail;
    //修改源数组
    let{tablist}=this.data;
    //foreach中的语法foreach(function(e,i,a)) 
    //e是必需/当前元素currentValue,i是可选/当前元素的索引值index,a是可选/当前元素所属的数组对象
    tablist.forEach((e,i)=>i===index?e.isActive=true:e.isActive=false)
    //赋值tabs回data
    this.setData({
      tablist
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //获取接口数据存入数组querypramas中
    this.queryparams.cid=options.cid;
    console.log(options)
    this.getgood_list();
  },
  //获取商品列表并且存入queryparams中
  async getgood_list(){
    const res=await request({url:"/goods/search",data:this.queryparams});
    //此处获取每一分类中的条目数
    const total=res.total;
    //计算页数
    this.totalpages=Math.ceil(total / this.queryparams.pagesize);
    this.setData({
      //将goods—_list修改成拼接数组
      goods_list:[...this.data.goods_list,...res.goods]
    })

  },
 

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    //下拉刷新 重置数组 重置页码 发送请求 返回数据后立刻关闭刷新效果
    this.setData({
      goods_list:[]
    })
    this.queryparams.pagenum=1;
    this.getgood_list();
    wx.stopPullDownRefresh({
      success: (res) => {},
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
   /*判断有无下一页数据
  获取总页数 因为只有总条数，计算页数=Math.ceil(条数 / 页容量)*/
  onReachBottom: function () {
    console.log("页面触底")
    //判断有无下一页数据
    if(this.queryparams.pagenum>=this.totalpages){
      wx.showToast({
        title: '已经是最后一页了',
      })
    }else{
      console.log("加载下一页")
      this.queryparams.pagenum++;
      this.getgood_list();
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})